export class Constants {
    public static emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    public static numberRegex = /^[0-9]+$/;
}